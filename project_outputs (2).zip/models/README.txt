Models saved with joblib. Load with: d = joblib.load(path); d['model'].predict(features)
The SVM pipeline contains a function named clip5 defined in the notebook; before loading in a NEW session, define:
    import numpy as np
    def clip5(Z): return np.clip(Z, -5.0, 5.0)
Input: log10-PSD features of shape (n, 2480) = 62 channels x 40 frequency points. Classes: 0 neutral, 1 sad, 2 fear, 3 happy.
Trained on 5 subjects only; use for demonstration, not as a general emotion detector.
