# Results summary (auto-generated)

Dataset actually used: SEED-IV copy from Kaggle (phhasian0710/seed-iv), 5 subjects, session 1, 4 classes, 1,410 segments of 1,024 samples at 200 Hz.
Pipeline: 75 Hz low-pass -> Symlets-4 MSPCA (level 5, Kaiser rule) -> MCOV (AR order 15, 40 PSD points, 0-75 Hz) -> classifiers.
Bagging+RF configuration: 10 bags, 10 trees per bag (the paper used 100 trees).

Accuracy by evaluation scheme (chance = 0.25):

|              |   Random 10-fold |   Trial-grouped 5-fold |   LOSO |
|:-------------|-----------------:|-----------------------:|-------:|
| DecisionTree |            0.46  |                  0.343 |  0.27  |
| RandomForest |            0.667 |                  0.433 |  0.309 |
| SVM          |            0.728 |                  0.506 |  0.343 |
| Bagging+RF   |            0.641 |                  0.425 |  0.323 |

Best model under the paper's random 10-fold protocol: SVM (0.728).
Best model under leave-one-subject-out: SVM (0.343).
The paper's 99.6% (3-class SEED, Bagging+RF) was NOT reproduced: our Bagging+RF reached 0.641 under random 10-fold on a different dataset.
